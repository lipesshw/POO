

package ru.cardapioru;

/**
 *
 * @author lipe
 */
public class Cardapioru {

    public static void main(String[] args) {
   
        InterfacePrincipal i = new InterfacePrincipal();
        
        // Define que a janela seja visível
        i.setVisible(true);
        
    }
}
