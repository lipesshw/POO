import javax.swing.JOptionPane;

public class Main {

    public static void main(String[] args) throws Exception {
        Restaurante restaurante = new Restaurante();
    }

}
