/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ru.cardapioru;

/**
 *
 * @author AlunoBCC
 */
public class Cardapioru {

    public static void main(String[] args) {
   
        InterfacePrincipal i = new InterfacePrincipal();
        
        // Define que a janela seja visível
        i.setVisible(true);
        
    }
}
