
//bibliotecas usadas
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Janela {

    Color novoDark = new Color(30, 31, 34);
    Color novoCinza = new Color(180, 180, 180);
    Color cinzaBotao = new Color(60, 63, 65);
    //lista para guardar dados
    List<String> database;

    public Janela() {
        database = new ArrayList<>();
    }

    //adicionar um item a lista que armazena os cardapios
    public void AdicionarItem(String data) {

        // add item na lista
        database.add(data);
        JOptionPane.showMessageDialog(null, "Item adicionado ao cardápio!");

    }

    // funcao para deletar a lista
    public void DeletarLista() {

        // caso esteja vazio
        if (database.isEmpty() == true) {

            JOptionPane.showMessageDialog(null, "Nenhum cardápio registrado!");

        } else {

            // caso não esteja vazio
            database.clear();
            JOptionPane.showMessageDialog(null, "Lista deletada!");

        }

    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////


    void Aplicacao() {

        // Criando a janela principal
        JFrame aluno_ou_funcionario = new JFrame("Restaurante Universitário - UFJ");
        aluno_ou_funcionario.setResizable(false);
        aluno_ou_funcionario.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        aluno_ou_funcionario.setSize(400, 200);

        // Painel principal com BoxLayout na vertical
        JPanel painel_aluno_ou_funcionario = new JPanel();
        painel_aluno_ou_funcionario.setLayout(new BoxLayout(painel_aluno_ou_funcionario, BoxLayout.Y_AXIS));
        painel_aluno_ou_funcionario.setBackground(new Color(30, 31, 34));

        // Adicionar borda ao painel
        painel_aluno_ou_funcionario.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Espaço interno de 10 pixels

        // Adicionando a imagem (exemplo com uma imagem placeholder)
        JLabel label1 = new JLabel(new ImageIcon("c:\\logo.png")); // Substitua com o caminho correto da sua imagem
        label1.setAlignmentX(Component.CENTER_ALIGNMENT); // Centraliza horizontalmente
        painel_aluno_ou_funcionario.add(label1);

        // Rótulo abaixo da imagem
        JLabel label_aluno_ou_funcionario = new JLabel("Escolha uma opção:");
        label_aluno_ou_funcionario.setForeground(novoCinza);
        label_aluno_ou_funcionario.setAlignmentX(Component.CENTER_ALIGNMENT); // Centraliza horizontalmente
        painel_aluno_ou_funcionario.add(label_aluno_ou_funcionario);

        // Painel para os botões aluno ou funcionário
        JPanel painel_botoes = new JPanel();
        painel_botoes.setBackground(novoDark);
        painel_botoes.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10)); // FlowLayout centralizado

        // Botões aluno ou funcionário
        JRadioButton RadioButton_aluno = new JRadioButton("Aluno");
        RadioButton_aluno.setBackground(novoDark);
        RadioButton_aluno.setForeground(novoCinza);
        RadioButton_aluno.setFocusable(false);

        JRadioButton RadioButton_funcionario = new JRadioButton("Funcionário");
        RadioButton_funcionario.setBackground(novoDark);
        RadioButton_funcionario.setForeground(novoCinza);
        RadioButton_funcionario.setFocusable(false);

        // Grupo de botões aluno ou funcionário
        ButtonGroup buttonGroup = new ButtonGroup();
        buttonGroup.add(RadioButton_aluno);
        buttonGroup.add(RadioButton_funcionario);

        // Adicionando os botões ao painel
        painel_botoes.add(RadioButton_aluno);
        painel_botoes.add(RadioButton_funcionario);

        // Adicionando o painel de botões ao painel principal
        painel_aluno_ou_funcionario.add(painel_botoes);

        // Adicionar espaço vertical entre os botões e o botão "Confirmar"
        painel_aluno_ou_funcionario.add(Box.createVerticalStrut(0));

        // Botão confirmar
        JButton Button_confirmar = new JButton("Confirmar");
        Button_confirmar.setAlignmentX(Component.CENTER_ALIGNMENT); // Centraliza horizontalmente
        Button_confirmar.setBackground(cinzaBotao);
        Button_confirmar.setForeground(novoCinza);
        Button_confirmar.setFocusable(false);

        // Arredondar a borda do botão
        Button_confirmar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(novoDark, 1), // Borda externa
                BorderFactory.createEmptyBorder(5, 15, 5, 15) // Espaço interno
        ));

        // Adicionar o botão ao painel
        painel_aluno_ou_funcionario.add(Button_confirmar);

        // Adicionar o painel na janela aluno ou funcionário
        aluno_ou_funcionario.add(painel_aluno_ou_funcionario);

        // Ação ao clicar no botão confirmar
        Button_confirmar.addActionListener(e -> {
            if (RadioButton_aluno.isSelected()) {
                // Caso selecione aluno
                Janela_Mostrar();
            } else if (RadioButton_funcionario.isSelected()) {
                // caso selecione funcionário
                aluno_ou_funcionario.dispose();
                loginFuncionario();
            } else {
                // caso o usuário não selecione nada
                JOptionPane.showMessageDialog(aluno_ou_funcionario, "Você precisa escolher uma opção antes de continuar.", "Ops...", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        // mostrar a janela
        aluno_ou_funcionario.setVisible(true);
    }



    void loginFuncionario() {

        // Criação da janela de login para funcionário
        JFrame janela = new JFrame();
        janela.setTitle("Login Funcionário");
        janela.setSize(300, 200);
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        janela.setLocationRelativeTo(null);

        // criando painel da janela
        JPanel painel = new JPanel(new GridLayout(5, 2));
        painel.setBackground(Color.LIGHT_GRAY);

        // rótulos e campos de login
        JLabel loginlabel = new JLabel("User :");
        JTextField loginfield = new JTextField(10);

        // rótulo e campo de senha
        JLabel senhalabel = new JLabel("Senha :");
        JPasswordField senhafield = new JPasswordField(10);

        // adicionando componentes ao painel
        painel.add(loginlabel);
        painel.add(loginfield);
        painel.add(senhalabel);
        painel.add(senhafield);

        // botão login
        JButton loginbutton = new JButton("Login");
        painel.add(loginbutton, BorderLayout.SOUTH);

        // adicionando o painel na janela no centro
        janela.add(painel, BorderLayout.CENTER);

        // Ação ao clicar no botão de login
        loginbutton.addActionListener(e -> {

            // obter as strings dos campos
            String login = loginfield.getText();
            char[] senharchars = senhafield.getPassword();
            String senha = new String(senharchars);

            // senha e login do funcionário
            if (login.equals("1") && senha.equals("1")) {

                // caso a verificação seja correta
                janela.dispose();
                JOptionPane.showMessageDialog(null, "Bem vindo!");
                Janela_Cardapio_Funcionario();

            } else {

                // caso a verificação seja incorreta
                JOptionPane.showMessageDialog(null, "Login ou senha inválidos!!!");

            }

        });

        // mostrar a janela atoa
        janela.setVisible(true);

    }

    void Janela_Cardapio_Funcionario() {

        // Configurações básicas da janela cardápio
        JFrame janelacardapio = new JFrame("Cadastrar Cardápio");
        janelacardapio.setSize(600, 400);
        janelacardapio.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        janelacardapio.setLocationRelativeTo(null);

        janelacardapio.setResizable(false);

        // Painel principal com borda vazia
        JPanel painelPrincipal = new JPanel();
        painelPrincipal.setBackground(novoDark);
        painelPrincipal.setForeground(novoCinza);
        painelPrincipal.setLayout(new BorderLayout());
        painelPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Borda com margens de 20 pixels

        // Rótulo do título
        JLabel rotulotitulo = new JLabel("Cadastrar Cardápio");
        rotulotitulo.setFont(new Font("Arial", Font.BOLD, 18));
        rotulotitulo.setHorizontalAlignment(JLabel.CENTER);
        rotulotitulo.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0)); // Borda na parte inferior do título
        rotulotitulo.setForeground(novoCinza);

        // Painel para os componentes superiores
        JPanel painelSuperior = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        painelSuperior.setBackground(novoDark);
        painelSuperior.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0)); // Borda interna

        // Dias da semana
        String[] diasdasemana = { "Segunda", "Terça", "Quarta", "Quinta", "Sexta" };
        JComboBox<String> caixadediasdasemana = new JComboBox<>(diasdasemana);
        caixadediasdasemana.setPreferredSize(new Dimension(120, 30)); // Tamanho preferencial

        // Rótulo e campo do cardápio
        JLabel rotulodocardapio = new JLabel("Cardápio:");
        JTextField cardapioTextField = new JTextField(20);
        cardapioTextField.setPreferredSize(new Dimension(200, 30)); // Tamanho preferencial
        cardapioTextField.setForeground(novoCinza);

        // Botão cadastrar
        JButton botaocadastrar = new JButton("+");
        botaocadastrar.setPreferredSize(new Dimension(50, 30)); // Tamanho preferencial
        botaocadastrar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(novoDark, 1), // Borda externa
                BorderFactory.createEmptyBorder(5, 15, 5, 15) // Espaço interno
        ));

        botaocadastrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String diaSelecionado = (String) caixadediasdasemana.getSelectedItem();
                String cardapio = cardapioTextField.getText();
                String estrutura = "\nCardápio de " + diaSelecionado + ":\n" + cardapio + "\n";

                if (cardapio.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Nada foi digitado no campo de texto!");
                } else {
                    AdicionarItem(estrutura);
                }
            }
        });

        // Adicionando componentes ao painel superior
        painelSuperior.add(new JLabel("Dia da semana (menu de escolha):"));
        painelSuperior.setForeground(novoCinza);
        painelSuperior.add(caixadediasdasemana);
        painelSuperior.add(rotulodocardapio);
        painelSuperior.add(cardapioTextField);
        painelSuperior.add(botaocadastrar);

        // Painel para os botões menores
        JPanel painelBotoesInferiores = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        painelBotoesInferiores.setBackground(novoDark);
        painelBotoesInferiores.setForeground(novoCinza);

        // Botões inferiores
        JButton mostrarcardapio = new JButton("Mostrar");
        JButton menuinicial = new JButton("Menu inicial");
        JButton deletarcardapio = new JButton("Deletar cardápio");

        // Configurando os botões inferiores
        mostrarcardapio.setPreferredSize(new Dimension(120, 30));
        menuinicial.setPreferredSize(new Dimension(120, 30));
        deletarcardapio.setPreferredSize(new Dimension(120, 30));

        deletarcardapio.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                DeletarLista();
            }
        });

        mostrarcardapio.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Janela_Mostrar();
            }
        });

        menuinicial.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                janelacardapio.dispose();
                Aplicacao();
            }
        });


        // Adicionando os botões inferiores ao painel
        painelBotoesInferiores.add(mostrarcardapio);
        painelBotoesInferiores.add(menuinicial);
        painelBotoesInferiores.add(deletarcardapio);


        // Adicionando os painéis ao painel principal
        painelPrincipal.add(rotulotitulo, BorderLayout.NORTH);
        painelPrincipal.add(painelSuperior, BorderLayout.CENTER);
        painelPrincipal.add(painelBotoesInferiores, BorderLayout.SOUTH);

        // Configurando a janela e tornando visível
        janelacardapio.getContentPane().add(painelPrincipal);
        janelacardapio.setVisible(true);
    }




    public void Janela_Mostrar(){
        // objeto da classe janela
        Janela janela = new Janela();

        // verifica se a lista está vazia
        if (database.isEmpty()) {

            // chama e abri a janela
            JOptionPane.showMessageDialog(null, "Não foi cadastrado um cardapio pra essa semana.");

        } else {

            // cria a janela para mostrar os dados

            // Objetos da janela
            JFrame janelamostrar = new JFrame();
            JPanel painelmostrar = new JPanel(new BorderLayout());
            JTextArea areadetexto = new JTextArea();
            JScrollPane scrollPane = new JScrollPane(areadetexto);
            JButton botaovoltar = new JButton("Voltar");

            // consfigurações básicas da janela.
            janelamostrar.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            janelamostrar.setSize(600, 400);
            janelamostrar.setLocationRelativeTo(null);
            areadetexto.setEditable(false);

            // para cada dados da lista ele adiciona na janela e pula uma linha
            for (String cardapio : database) {

                //adicionar texto na area de trabalho
                areadetexto.append(cardapio + "\n");

            }

            // adiciona os dados ao painel
            painelmostrar.add(botaovoltar, BorderLayout.NORTH);
            painelmostrar.add(scrollPane, BorderLayout.CENTER);

            // adiciona o painel a janela
            janelamostrar.getContentPane().add(painelmostrar);
            janelamostrar.setBackground(Color.LIGHT_GRAY);

            // ação ao cliclar o botao voltar
            botaovoltar.addActionListener(new ActionListener() {

                public void actionPerformed(ActionEvent e) {

                    // fecha a janela
                    janelamostrar.dispose();

                }

            });

            // deixar a janela visível
            janelamostrar.setVisible(true);

        }

    }

}
